<?php
    echo "def";
?>